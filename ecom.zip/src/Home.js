
import React from "react";
import "./Home.css";
import Product from "./Product";

function Home() {
  return (
    <div className="home">
      <div className="home__container">
        <img
          className="home__image"
          src="https://wallpaperaccess.com/full/3658600.jpg"
          alt=""
        />

        <div className="home__row">
          <Product
            id="12321341"
            title="God Father"
            price={9.99}
            rating={5}
            image="https://m.media-amazon.com/images/M/MV5BMWMwMGQzZTItY2JlNC00OWZiLWIyMDctNDk2ZDQ2YjRjMWQ0XkEyXkFqcGdeQXVyNzkwMjQ5NzM@._V1_.jpg"
          />
          <Product
            id="49538094"
            title="Joker"
            price={8.88}
            rating={4}
            image="https://m.media-amazon.com/images/M/MV5BNGVjNWI4ZGUtNzE0MS00YTJmLWE0ZDctN2ZiYTk2YmI3NTYyXkEyXkFqcGdeQXVyMTkxNjUyNQ@@._V1_.jpg"
          />
        </div>

        <div className="home__row">
          <Product
            id="4903850"
            title="Pursuit of happiness"
            price={7.99}
            rating={5}
            image="https://miro.medium.com/max/548/1*Y8vXN1mJeEHyXWJtFICjiQ.jpeg"
          />
          <Product
            id="23445930"
            title="Avengers-End Game"
            price={8.99}
            rating={4}
            image="https://upload.wikimedia.org/wikipedia/en/0/0d/Avengers_Endgame_poster.jpg"
          />
          <Product
            id="3254354345"
            title="Master"
            price={9.99}
            rating={5}
            image="https://m.media-amazon.com/images/M/MV5BYWQxODNlMjktNjU3Yi00OTFmLTgyOTgtZDVhNDY5NzMwMmYwXkEyXkFqcGdeQXVyMTIwNjE1MTk0._V1_.jpg"
          />
        </div>

        <div className="home__row">
          <Product
            id="90829332"
            title="Soorarai Pottru"
            price={9.99}
            rating={4}
            image="https://img.onmanorama.com/content/dam/mm/en/entertainment/entertainment-news/images/2020/10/23/suriya-soorarai-pottru.jpg"
          />
        </div>
        
        <div className="home__row">
          <Product
            id="4903850"
            title="Thupaaki"
            price={6.99}
            rating={4}
            image="https://data1.ibtimes.co.in/en/full/321219/quotthuppakkiquot-film-poster.jpg"
          />
          <Product
            id="23445930"
            title="Pulp Fiction"
            price={8.99}
            rating={3}
            image="https://deepfocusreview.com/wp-content/uploads/2016/12/pulp_fiction.jpg"
          />
          <Product
            id="3254354345"
            title="Dead pool"
            price={9.99}
            rating={5}
            image="https://m.media-amazon.com/images/M/MV5BYzE5MjY1ZDgtMTkyNC00MTMyLThhMjAtZGI5OTE1NzFlZGJjXkEyXkFqcGdeQXVyNjU0OTQ0OTY@._V1_.jpg"
          />
        </div>

        <div className="home__row">
          <Product
            id="90829332"
            title="Justice League"
            price={10.99}
            rating={3}
            image="https://thedirect.s3.amazonaws.com/media/article_full/jlco.jpg"
          />
        </div>
        <div className="home__row">
          <Product
            id="12321341"
            title="Matrix"
            price={9.99}
            rating={5}
            image="https://flxt.tmsimg.com/assets/p22804_p_v10_ab.jpg"
          />
          <Product
            id="49538094"
            title="Varanam Ayiram"
            price={8.88}
            rating={4}
            image="https://in.bmscdn.com/iedb/movies/images/mobile/thumbnail/xlarge/varanam-aayiram-edited-version-et00002204-15-02-2021-02-51-33.jpg"
          />
        </div>
        <div className="home__row">
          <Product
            id="90829332"
            title="Mankatha"
            price={7.99}
            rating={4}
            image="https://images.cinemaexpress.com/uploads/user/imagelibrary/2019/8/31/original/40.jpg"
          />
        </div>
      </div>
    </div>
  );
}

export default Home;