import firebase from "firebase";

const firebaseConfig = {
    apiKey: "AIzaSyA3saKR7yvg00aRbHv9amXxncsndCUibyw",
    authDomain: "rahul-movie.firebaseapp.com",
    projectId: "rahul-movie",
    storageBucket: "rahul-movie.appspot.com",
    messagingSenderId: "787791088843",
    appId: "1:787791088843:web:9828da9911a861a4271f4e",
    measurementId: "G-0TK3H5CF9N"
  };

const firebaseApp = firebase.initializeApp(firebaseConfig);

const db = firebaseApp.firestore();
const auth = firebase.auth();

export { db, auth };